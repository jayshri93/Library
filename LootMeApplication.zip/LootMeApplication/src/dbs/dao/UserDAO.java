package dbs.dao;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import dbs.application.DBConnection;
import dbs.pojo.User;

public class UserDAO {
	public static boolean AuthenticateUser(User obj) {
		Connection con= DBConnection.getConnection();
		try {
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from customer where loginId="+"'" +obj.getLoginId()+"' and password='"+obj.getPassword()+"'");
			if(rs.next()) {
				return true;
			}
			else {
				return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

}
