package dbs.pojo;

public class Plan {
	private String PlanId;
	private String PlanName;
	private int APR;
	private int Tenture;
	public String getPlanId() {
		return PlanId;
	}
	public void setPlanId(String planId) {
		PlanId = planId;
	}
	public String getPlanName() {
		return PlanName;
	}
	public void setPlanName(String planName) {
		PlanName = planName;
	}
	public int getAPR() {
		return APR;
	}
	public void setAPR(int aPR) {
		APR = aPR;
	}
	public int getTenture() {
		return Tenture;
	}
	public void setTenture(int tenture) {
		Tenture = tenture;
	}
	
	
}
