package dbs.pojo;

import java.util.Date;

public class CustomerCallLogs {
	public String getUID() {
		return UID;
	}
	public void setUID(String uID) {
		UID = uID;
	}
	public String getPhNumber() {
		return phNumber;
	}
	public void setPhNumber(String phNumber) {
		this.phNumber = phNumber;
	}
	public int getDuration() {
		return Duration;
	}
	public void setDuration(int duration) {
		Duration = duration;
	}
	public int getAmount() {
		return Amount;
	}
	public void setAmount(int amount) {
		Amount = amount;
	}
	public Date getCallDate() {
		return CallDate;
	}
	public void setCallDate(Date callDate) {
		CallDate = callDate;
	}
	private String UID;
	private String phNumber;
	private int Duration;
	private int Amount;
	private Date CallDate;

}
