package dbs.pojo;

import java.util.Date;

public class Calls {
 private String Cid;
 public String getCid() {
	return Cid;
}
public void setCid(String cid) {
	Cid = cid;
}
public String getUid() {
	return Uid;
}
public void setUid(String uid) {
	Uid = uid;
}
public int getDuration() {
	return Duration;
}
public void setDuration(int duration) {
	Duration = duration;
}
public String getType() {
	return Type;
}
public void setType(String type) {
	Type = type;
}
public int getUnitPrice() {
	return UnitPrice;
}
public void setUnitPrice(int unitPrice) {
	UnitPrice = unitPrice;
}
public int getAmount() {
	return Amount;
}
public void setAmount(int amount) {
	Amount = amount;
}
public Date getCallDate() {
	return CallDate;
}
public void setCallDate(Date callDate) {
	CallDate = callDate;
}
private String Uid;
 private int Duration;
 private String Type;
 private int UnitPrice;
 private int Amount;
 private Date CallDate;
			
}
