package dbs.pojo;

public class Customer {
	private String PhNumber;
	private String Name;
	private String PlanID;
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getPlanID() {
		return PlanID;
	}
	public void setPlanID(String planID) {
		PlanID = planID;
	}
	public String getPhNumber() {
		return PhNumber;
	}
	public void setPhNumber(String phNumber) {
		PhNumber = phNumber;
	}
	private String CID;
	public String getCID() {
		return CID;
	}
	public void setCID(String cID) {
		CID = cID;
	}
	
	
}
