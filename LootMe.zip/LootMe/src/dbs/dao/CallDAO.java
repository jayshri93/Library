package dbs.dao;

import java.util.List;

import dbs.pojo.Calls;

public class CallDAO {

	public static List<Calls> getCallLogsForCustomer(String customerId) {
		// TODO Auto-generated method stub
		return null;
	}

}
