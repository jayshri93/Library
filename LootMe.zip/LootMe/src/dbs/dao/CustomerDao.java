package dbs.dao;

import java.sql.*;
import java.util.*;

import dbs.application.DBConnection;
import dbs.pojo.CustomerCallLogs;
import dbs.pojo.Plan;

public class CustomerDao {

	Connection connection = DBConnection.getConnection();
	private List<CustomerCallLogs> callLog;
	CustomerCallLogs call = new CustomerCallLogs();

	public List<CustomerCallLogs> getCustomerCallLog(String custId) {

		try {
			Statement st = connection.createStatement();
			ResultSet rs = st.executeQuery(
					"select c.PhNumber,cc.Caldate,cc.Uid,cc.Duration,cc.Amount from customer c join Calls cc where name ="
							+ custId + "and cc.Amount>10 and cc.Type='ISD' or cc.Type='STD'");
			while (rs.next()) {
				call.setAmount(rs.getInt(5));
				call.setCallDate(rs.getDate(2));
				call.setDuration(rs.getInt(4));
				call.setPhNumber(rs.getString(1));
				call.setUID(rs.getString(3));
				callLog.add(call);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return callLog;
	}

	public Plan fetchPlanDeatils(String planId) {
		Statement st;
		Plan p = new Plan();
		try {
			st = connection.createStatement();
			ResultSet rs = st.executeQuery("select * from Plan where planId=" + planId);

			if (rs.next()) {
				p.setAPR(rs.getInt("APR"));
				p.setPlanId(rs.getString("PlanId"));
				p.setPlanName(rs.getString("PlanName"));
				p.setTenture(rs.getInt("Tenture"));

			} else
				p = null;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			p = null;
			e.printStackTrace();
		}
		return p;
	}

}
